from django.shortcuts import render, redirect
from .models import Post
from .forms import PostForm
# Create your views here.
def home(request):
    return render(request, 'posts/home.html')  # Renders the 'home.html' template

def post_list(request):
    posts = Post.objects.all()  # Get all posts
    return render(request, 'posts/post_list.html', {'posts': posts})

def add_post(request):
    print("add_post view accessed")
    if request.method == 'POST':
        print("Form submitted")
        form = PostForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('post_list')  # Redirect to post list after saving
    else:
        form = PostForm()
    print("add_post view was called")
    return render(request, 'posts/add_post.html', {'form': form})